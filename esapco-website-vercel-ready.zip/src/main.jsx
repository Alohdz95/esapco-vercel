import React from 'react'
import ReactDOM from 'react-dom/client'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <h1>ESAPCO Software</h1>
    <p>¡Sitio listo para publicar en Vercel!</p>
  </React.StrictMode>
)